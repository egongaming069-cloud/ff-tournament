import { useQueryClient } from "@tanstack/react-query";
import { 
  useListRegistrations as useGeneratedList, 
  useCreateRegistration as useGeneratedCreate,
  getListRegistrationsQueryKey 
} from "@workspace/api-client-react";

export function useRegistrations() {
  return useGeneratedList({
    query: {
      staleTime: 1000 * 60, // 1 minute
      retry: 1
    }
  });
}

export function useRegister() {
  const queryClient = useQueryClient();
  
  return useGeneratedCreate({
    mutation: {
      onSuccess: () => {
        // Invalidate the list so it updates with the new registration
        queryClient.invalidateQueries({ queryKey: getListRegistrationsQueryKey() });
      }
    }
  });
}
