import { useRegistrations } from "@/hooks/use-registrations";
import { format } from "date-fns";
import { motion } from "framer-motion";
import { Search, Users, RefreshCw, Download } from "lucide-react";
import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

function downloadCSV(registrations: { id: number; ign: string; squad: string; uid: string; createdAt: string }[]) {
  const headers = ["ID", "IGN", "Squad", "UID", "Registered At"];
  const rows = registrations.map(r => [
    r.id,
    `"${r.ign.replace(/"/g, '""')}"`,
    `"${r.squad.replace(/"/g, '""')}"`,
    r.uid,
    format(new Date(r.createdAt), "yyyy-MM-dd HH:mm:ss"),
  ]);
  const csv = [headers.join(","), ...rows.map(r => r.join(","))].join("\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `ff-tournament-backup-${format(new Date(), "yyyyMMdd-HHmm")}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

export default function Admin() {
  const { data: registrations, isLoading, isError, refetch, isFetching } = useRegistrations();
  const [search, setSearch] = useState("");

  const filtered = registrations?.filter(r => 
    r.ign.toLowerCase().includes(search.toLowerCase()) || 
    r.squad.toLowerCase().includes(search.toLowerCase()) ||
    r.uid.includes(search)
  ) || [];

  return (
    <div className="container mx-auto px-4 py-12 max-w-6xl">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6 mb-10">
        <div>
          <h1 className="text-4xl md:text-5xl font-display font-bold text-glow text-primary mb-2">
            Tournament Roster
          </h1>
          <p className="text-muted-foreground">
            All confirmed registrations for the upcoming tournament.
          </p>
        </div>
        
        <div className="flex w-full md:w-auto items-center gap-4">
          <div className="relative w-full md:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input 
              placeholder="Search IGN, Squad, UID..." 
              className="pl-9 bg-card"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <Button 
            variant="outline" 
            size="icon" 
            onClick={() => refetch()} 
            disabled={isFetching}
            className="shrink-0"
          >
            <RefreshCw className={`w-4 h-4 ${isFetching ? 'animate-spin text-primary' : ''}`} />
          </Button>
          <Button
            variant="outline"
            size="icon"
            onClick={() => registrations && registrations.length > 0 && downloadCSV(registrations)}
            disabled={!registrations || registrations.length === 0}
            className="shrink-0"
            title="Download backup CSV"
          >
            <Download className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map(i => (
            <Card key={i} className="animate-pulse bg-card/40 border-border/20">
              <CardContent className="h-32 p-6 flex flex-col justify-center gap-3">
                <div className="h-5 bg-border/40 rounded w-1/2" />
                <div className="h-4 bg-border/30 rounded w-1/3" />
                <div className="h-3 bg-border/20 rounded w-1/4 mt-auto" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : isError ? (
        <Card className="border-destructive/50 bg-destructive/5">
          <CardContent className="py-12 text-center text-destructive">
            <p>Failed to load registrations. Server might be offline.</p>
            <Button variant="outline" className="mt-4" onClick={() => refetch()}>Try Again</Button>
          </CardContent>
        </Card>
      ) : filtered.length === 0 ? (
        <Card className="border-dashed border-2 border-border/50 bg-transparent shadow-none">
          <CardContent className="py-20 flex flex-col items-center justify-center text-center">
            <Users className="w-16 h-16 text-muted-foreground/30 mb-4" />
            <h3 className="text-xl font-display font-bold text-foreground mb-1">No players found</h3>
            <p className="text-muted-foreground">
              {search ? "No registrations match your search criteria." : "No one has registered for the tournament yet."}
            </p>
          </CardContent>
        </Card>
      ) : (
        <>
          <div className="mb-6 flex items-center gap-3">
            <div className="px-3 py-1 rounded bg-secondary text-secondary-foreground text-sm font-semibold font-display tracking-widest">
              Total Squads: {new Set(filtered.map(r => r.squad.toLowerCase())).size}
            </div>
            <div className="px-3 py-1 rounded bg-secondary text-secondary-foreground text-sm font-semibold font-display tracking-widest">
              Total Players: {filtered.length}
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filtered.map((player, index) => (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: index * 0.05 }}
                key={player.id}
              >
                <Card className="group hover:-translate-y-1 transition-all duration-300 hover:shadow-primary/10 hover:border-primary/50">
                  <CardContent className="p-6">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <p className="text-xs uppercase tracking-widest text-primary font-bold mb-1 line-clamp-1">{player.squad}</p>
                        <h3 className="text-xl font-display font-bold text-foreground leading-none">{player.ign}</h3>
                      </div>
                      <div className="text-xs text-muted-foreground font-mono bg-background px-2 py-1 rounded border border-border/50">
                        #{player.id}
                      </div>
                    </div>
                    
                    <div className="space-y-2 mt-4 pt-4 border-t border-border/30">
                      <div className="flex justify-between items-center text-sm">
                        <span className="text-muted-foreground uppercase tracking-wider text-xs">UID</span>
                        <span className="font-mono text-foreground">{player.uid}</span>
                      </div>
                      <div className="flex justify-between items-center text-sm">
                        <span className="text-muted-foreground uppercase tracking-wider text-xs">Registered</span>
                        <span className="text-muted-foreground text-xs">
                          {format(new Date(player.createdAt), 'MMM dd, HH:mm')}
                        </span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
