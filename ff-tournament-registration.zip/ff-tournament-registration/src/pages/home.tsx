import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { motion, AnimatePresence } from "framer-motion";
import { Trophy, Users, User, CheckCircle2, ChevronRight, AlertCircle } from "lucide-react";
import { Link } from "wouter";

import { useRegister } from "@/hooks/use-registrations";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

// Schema matching the OpenAPI spec for CreateRegistrationInput
const registrationSchema = z.object({
  ign: z.string().min(3, "IGN must be at least 3 characters").max(30),
  squad: z.string().min(2, "Squad name must be at least 2 characters").max(30),
  uid: z.string().min(5, "UID must be valid").max(20).regex(/^\d+$/, "UID must contain only numbers"),
});

type RegistrationForm = z.infer<typeof registrationSchema>;

export default function Home() {
  const [successData, setSuccessData] = useState<RegistrationForm | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  
  const { mutate: register, isPending } = useRegister();
  
  const { register: formRegister, handleSubmit, formState: { errors } } = useForm<RegistrationForm>({
    resolver: zodResolver(registrationSchema),
  });

  const onSubmit = (data: RegistrationForm) => {
    setErrorMsg(null);
    register({ data }, {
      onSuccess: () => {
        setSuccessData(data);
      },
      onError: (err: any) => {
        // Typically Orval custom fetch wrappers will reject with the parsed JSON if available
        const message = err?.message || err?.response?.data?.message || "UID already registered or submission failed.";
        setErrorMsg(message);
      }
    });
  };

  return (
    <div className="relative min-h-[calc(100vh-4rem)] flex items-center">
      {/* Background Hero Image */}
      <div className="absolute inset-0 z-0">
        <img 
          src={`${import.meta.env.BASE_URL}images/hero-bg.png`} 
          alt="E-sports Background" 
          className="w-full h-full object-cover opacity-30"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/50 to-transparent" />
      </div>

      <div className="container mx-auto px-4 z-10 py-12 md:py-24">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          
          {/* Left Column: Epic Copy */}
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="space-y-6"
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary text-sm font-display tracking-widest uppercase mb-4">
              <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
              Registrations Open
            </div>
            <h1 className="text-5xl md:text-7xl font-display font-bold leading-[1.1] text-foreground">
              THE ULTIMATE <br />
              <span className="text-primary text-glow">BATTLEGROUND</span> <br />
              AWAITS YOU.
            </h1>
            <p className="text-lg text-muted-foreground max-w-lg leading-relaxed">
              Assemble your squad, lock in your spot, and prepare to drop into the most intense Free Fire tournament of the season. 
              Only the strongest survive.
            </p>
            <div className="pt-4 flex gap-8">
              <div className="space-y-1">
                <p className="font-display text-3xl font-bold text-foreground">10K+</p>
                <p className="text-xs text-muted-foreground uppercase tracking-widest">Prize Pool</p>
              </div>
              <div className="w-px h-12 bg-border/50" />
              <div className="space-y-1">
                <p className="font-display text-3xl font-bold text-foreground">50</p>
                <p className="text-xs text-muted-foreground uppercase tracking-widest">Squads Max</p>
              </div>
            </div>
          </motion.div>

          {/* Right Column: Registration Form / Success State */}
          <motion.div 
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2, ease: "easeOut" }}
            className="w-full max-w-md mx-auto lg:ml-auto"
          >
            <AnimatePresence mode="wait">
              {!successData ? (
                <motion.div
                  key="form"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                >
                  <Card className="backdrop-blur-xl bg-card/60">
                    <CardHeader>
                      <CardTitle>Enroll Your Roster</CardTitle>
                      <CardDescription>Enter your official game details below.</CardDescription>
                    </CardHeader>
                    <CardContent>
                      {errorMsg && (
                        <div className="mb-6 p-4 bg-destructive/10 border border-destructive/30 rounded flex items-start gap-3">
                          <AlertCircle className="w-5 h-5 text-destructive shrink-0 mt-0.5" />
                          <p className="text-sm text-destructive">{errorMsg}</p>
                        </div>
                      )}

                      <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
                        <div className="space-y-2 relative">
                          <Label htmlFor="ign" className="flex items-center gap-2">
                            <User className="w-4 h-4 text-primary" />
                            In-Game Name (IGN)
                          </Label>
                          <Input 
                            id="ign" 
                            placeholder="e.g. DESTROYER" 
                            {...formRegister("ign")}
                            className={errors.ign ? "border-destructive focus-visible:ring-destructive" : ""}
                          />
                          {errors.ign && <p className="text-xs text-destructive absolute -bottom-5">{errors.ign.message}</p>}
                        </div>

                        <div className="space-y-2 relative pt-2">
                          <Label htmlFor="squad" className="flex items-center gap-2">
                            <Users className="w-4 h-4 text-primary" />
                            Squad Name
                          </Label>
                          <Input 
                            id="squad" 
                            placeholder="e.g. Alpha Team" 
                            {...formRegister("squad")}
                            className={errors.squad ? "border-destructive focus-visible:ring-destructive" : ""}
                          />
                          {errors.squad && <p className="text-xs text-destructive absolute -bottom-5">{errors.squad.message}</p>}
                        </div>

                        <div className="space-y-2 relative pt-2">
                          <Label htmlFor="uid" className="flex items-center gap-2">
                            <Trophy className="w-4 h-4 text-primary" />
                            Player UID
                          </Label>
                          <Input 
                            id="uid" 
                            placeholder="e.g. 1234567890" 
                            {...formRegister("uid")}
                            className={errors.uid ? "border-destructive focus-visible:ring-destructive" : ""}
                          />
                          {errors.uid && <p className="text-xs text-destructive absolute -bottom-5">{errors.uid.message}</p>}
                        </div>

                        <Button 
                          type="submit" 
                          size="lg" 
                          className="w-full mt-6 group"
                          disabled={isPending}
                        >
                          {isPending ? "Connecting..." : "Confirm Registration"}
                          {!isPending && <ChevronRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />}
                        </Button>
                      </form>
                    </CardContent>
                  </Card>
                </motion.div>
              ) : (
                <motion.div
                  key="success"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                >
                  <Card className="border-primary/50 bg-card/80 backdrop-blur-xl relative overflow-hidden">
                    <div className="absolute top-0 right-0 p-32 bg-primary/20 blur-[100px] rounded-full pointer-events-none" />
                    <CardContent className="pt-12 pb-10 flex flex-col items-center text-center">
                      <div className="w-20 h-20 bg-primary/20 rounded-full flex items-center justify-center mb-6">
                        <CheckCircle2 className="w-10 h-10 text-primary" />
                      </div>
                      <h2 className="text-3xl font-display font-bold text-foreground mb-2">Registration Locked!</h2>
                      <p className="text-muted-foreground mb-8">
                        Your slot has been confirmed. Prepare for battle, <span className="text-primary font-bold">{successData.ign}</span>.
                      </p>

                      <div className="w-full bg-background/50 rounded-sm p-4 border border-border/50 space-y-3 text-left mb-8">
                        <div className="flex justify-between items-center border-b border-border/50 pb-2">
                          <span className="text-xs uppercase tracking-widest text-muted-foreground">Squad</span>
                          <span className="font-mono text-sm">{successData.squad}</span>
                        </div>
                        <div className="flex justify-between items-center border-b border-border/50 pb-2">
                          <span className="text-xs uppercase tracking-widest text-muted-foreground">UID</span>
                          <span className="font-mono text-sm">{successData.uid}</span>
                        </div>
                        <div className="flex justify-between items-center pb-1">
                          <span className="text-xs uppercase tracking-widest text-muted-foreground">Status</span>
                          <span className="text-sm font-bold text-primary animate-pulse">CONFIRMED</span>
                        </div>
                      </div>

                      <div className="flex gap-4 w-full">
                        <Button variant="outline" className="w-full" onClick={() => setSuccessData(null)}>
                          Register Another
                        </Button>
                        <Link href="/admin" className="w-full">
                          <Button className="w-full">View Roster</Button>
                        </Link>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
