import { Link, useLocation } from "wouter";
import { Trophy } from "lucide-react";
import { cn } from "@/lib/utils";

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();

  return (
    <div className="min-h-screen flex flex-col bg-background selection:bg-primary/30">
      <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/80 backdrop-blur-md">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2 group">
            <Trophy className="w-6 h-6 text-primary group-hover:animate-pulse" />
            <span className="font-display font-bold text-xl tracking-wider text-foreground group-hover:text-primary transition-colors">
              FF<span className="text-primary">SERIES</span>
            </span>
          </Link>
          <nav className="flex items-center gap-6">
            <Link 
              href="/" 
              className={cn(
                "text-sm font-semibold uppercase tracking-wider font-display transition-colors hover:text-primary",
                location === "/" ? "text-primary" : "text-muted-foreground"
              )}
            >
              Register
            </Link>
            <Link 
              href="/admin" 
              className={cn(
                "text-sm font-semibold uppercase tracking-wider font-display transition-colors hover:text-primary",
                location === "/admin" ? "text-primary" : "text-muted-foreground"
              )}
            >
              Roster
            </Link>
          </nav>
        </div>
      </header>
      
      <main className="flex-1 w-full relative">
        {children}
      </main>

      <footer className="border-t border-border/40 bg-card/30 py-6 mt-12">
        <div className="container mx-auto px-4 text-center">
          <p className="text-sm text-muted-foreground font-display tracking-widest uppercase">
            &copy; {new Date().getFullYear()} Free Fire Tournament Series. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}
