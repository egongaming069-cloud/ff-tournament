# Free Fire Tournament Registration

A full-stack web app for managing Free Fire tournament player registrations.

## Features

- **Registration Form** — Players register with In-Game Name (IGN), Squad Name, and UID
- **Duplicate Prevention** — Same UID cannot register twice
- **Tournament Roster** — Browse and search all registered players
- **CSV Backup** — Download all registrations as a CSV file from the Roster page

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React + Vite + TypeScript |
| Styling | Tailwind CSS + shadcn/ui |
| Forms | React Hook Form + Zod |
| Backend | Node.js + Express 5 |
| Database | PostgreSQL + Drizzle ORM |
| API Contract | OpenAPI 3.1 + Orval codegen |

## Project Structure

```
ff-tournament-registration/
├── src/                  # React frontend
│   ├── pages/
│   │   ├── home.tsx      # Registration form page
│   │   └── admin.tsx     # Roster + CSV backup page
│   ├── hooks/
│   │   └── use-registrations.ts
│   └── components/
├── server/               # Express API server
│   └── src/
│       └── routes/
│           └── registrations.ts
├── db/                   # Drizzle ORM schema
│   └── src/schema/
│       └── registrations.ts
└── api-spec/
    └── openapi.yaml      # API contract
```

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/api/registrations` | Register a player |
| `GET` | `/api/registrations` | List all registrations |

### POST /api/registrations

**Request body:**
```json
{
  "ign": "DESTROYER99",
  "squad": "Alpha Team",
  "uid": "1234567890"
}
```

**Response (201):**
```json
{
  "id": 1,
  "ign": "DESTROYER99",
  "squad": "Alpha Team",
  "uid": "1234567890",
  "createdAt": "2026-03-22T11:54:00.000Z"
}
```

**Response (409)** — if UID already registered:
```json
{ "message": "This UID is already registered for the tournament." }
```

## Database Schema

```sql
CREATE TABLE registrations (
  id         SERIAL PRIMARY KEY,
  ign        TEXT NOT NULL,
  squad      TEXT NOT NULL,
  uid        TEXT NOT NULL UNIQUE,
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);
```

## Setup & Running

### Prerequisites
- Node.js 18+
- PostgreSQL database
- pnpm

### Environment Variables

```env
DATABASE_URL=postgresql://user:password@host:5432/dbname
PORT=8080
```

### Install & Run

```bash
# Install dependencies
pnpm install

# Push DB schema
pnpm --filter @workspace/db run push

# Start API server
pnpm --filter @workspace/api-server run dev

# Start frontend (separate terminal)
pnpm --filter @workspace/ff-tournament run dev
```

## CSV Backup

Go to the **Roster** page and click the download icon (↓) in the top-right corner to export all registrations as a CSV file. The file is named with the current timestamp, e.g. `ff-tournament-backup-20260322-1154.csv`.

## License

MIT
