import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import { registrationsTable, insertRegistrationSchema } from "@workspace/db/schema";
import { CreateRegistrationBody } from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/registrations", async (req, res) => {
  try {
    const registrations = await db.select().from(registrationsTable).orderBy(registrationsTable.createdAt);
    res.json(registrations);
  } catch (err) {
    req.log.error({ err }, "Failed to list registrations");
    res.status(500).json({ message: "Internal server error" });
  }
});

router.post("/registrations", async (req, res) => {
  try {
    const parsed = CreateRegistrationBody.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ message: "Invalid request body" });
      return;
    }

    const { ign, squad, uid } = parsed.data;
    const validated = insertRegistrationSchema.parse({ ign, squad, uid });

    const [registration] = await db
      .insert(registrationsTable)
      .values(validated)
      .returning();

    res.status(201).json(registration);
  } catch (err: any) {
    if (err?.code === "23505") {
      res.status(409).json({ message: "This UID is already registered for the tournament." });
      return;
    }
    req.log.error({ err }, "Failed to create registration");
    res.status(500).json({ message: "Internal server error" });
  }
});

export default router;
